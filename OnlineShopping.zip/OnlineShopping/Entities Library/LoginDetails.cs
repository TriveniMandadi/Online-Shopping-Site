﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingEntityLib
{
    /// <summary>
    /// Login Details Class
    /// </summary>
    public class LoginDetails
    {
        /// <summary>
        /// User Name (name of the user)
        /// </summary>
        public string UserName { get; set; }        

        /// <summary>
        /// Password( Password set by user)
        /// </summary>
        public string Password { get; set; }        
    }
}
