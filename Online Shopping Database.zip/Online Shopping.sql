create table ol_login
(
	username varchar(30),
	--email varchar(40),
	password varchar(10),
	confirm_pwd varchar(10)
)

insert into ol_login (username,password,confirm_pwd)
			values('Triveni','Triv1234','Triv1234')
insert into ol_login (username,password,confirm_pwd)
			values('Triv','Triv5678','Triv5678')
insert into ol_login (username,password,confirm_pwd)
			values('Abc','Abc1234','Abc1234')

select * from ol_login

create table ol_category
(
	cid int primary key identity,
	cname varchar(50)
)

insert into ol_category values('Clothing')
insert into ol_category values('Footwear')
insert into ol_category values('Watches')
insert into ol_category values('Bags')
insert into ol_category values('Sunglasses')

select * from ol_category

create table ol_product
(
	pid int primary key identity,
	cid int references ol_category(cid),
	pname varchar(50),
	picture varchar(50),
	price int,
	content varchar(max)
)

insert into ol_product values(1,'Sweat Shirt','sweatshirt.png',640,'Material : Cotton,Size : M,Color : Pink')
insert into ol_product values(1,'T-Shirt','tshirt.png',404,'Brand : Campus Sutra,Color: Black,Size : M')
insert into ol_product values(1,'Top','top.png',359,'Brand : Campus Sutra,Color : White,Size : M')
insert into ol_product values(1,'Men Shirt','shirt.png',749,'Brand : Here & Now,Color : Red & White,Size: M')
insert into ol_product values(1,'JSuit','suit.png',759,'Brand : Tolyo Talkies,Color : Navy Blue & White')
insert into ol_product values(1,'A-Line Dress','dress.png',999,'Brand : Mango,Design : Striped,Color : Multicolor')
insert into ol_product values(1,'Wrogon Shirt','vWrogn1.png',1264,'Brand : Wrogn,Color : Olive Green,Size : M')
insert into ol_product values(1,'Wrogn ','vWrogn2.png',1099,'Brand : Wrogn,Color : Black Slim Fit')
insert into ol_product values(1,'3Shirt','shirtT.png',474,'Type : Casual Wear,Size : M')
insert into ol_product values(2,'One Toe Flats','toe flats.png',549,'Brand : Vishudh,Color : Grey,Size : 41,Type : One toe')
insert into ol_product values(2,'High Heels','heels.png',629,'Brand : Roadster,Color : Peach,Size : Euro40')
insert into ol_product values(2,'Shoes','shoes.png',13699,'Brand : Timberland,Color : Off-White,Height : 6 inch')
insert into ol_product values(2,'Festive Flats','festflats.png',798,'Brand : Vishudh,Size : 41')
insert into ol_product values(2,'Flats','flats.png',2399,'Color : Pink,Type : Open-Toed,Back : Buckle,Pattern : Solid')
insert into ol_product values(3,'Smart Watch','smart watch.png',3799,'Brand : Amazfit,Color : Black,Size : One-Size')
insert into ol_product values(3,'Titan Watch','titan.png',1995,'Brand : Titan, Model : Strap,Size : One-Size,Type : Analogue')
insert into ol_product values(3,'Fastrack Watch','fastrack.png',2650,'Brand : Fastrack,Model : Chain,Color: Blue')
insert into ol_product values(3,'Fossil Watch','fossil.png',7366,'Brand : Fossil,Color : Rose-Gold,Size : One - Size')
insert into ol_product values(4,'Sling Bag','lychee.png',599,'Brand : Lychee,Size : One-Size,Color : Grey')
insert into ol_product values(4,'Combo Sling','csling.png',799,'Brand : Bagsy Malone,Size : One - Size')
insert into ol_product values(4,'Luggage Bags','luggage bag.png',11808,'Brand : IT Luggage,Size : Pack,Color : Blue')
insert into ol_product values(5,'Sun Glasses','sunglass.png',1264,'Brand : Omnitech,Color:Greyish-Black')

select * from ol_product

select pname,picture,price from ol_product where pname like 'Clothing'
select * from ol_product where pid=1

create table ol_cart
(
	pid int references ol_product(pid),	
	pname varchar(50),
	picture varchar(50),	
	price int,
	qty int,
)

delete from ol_cart where pid=22

select * from ol_cart




